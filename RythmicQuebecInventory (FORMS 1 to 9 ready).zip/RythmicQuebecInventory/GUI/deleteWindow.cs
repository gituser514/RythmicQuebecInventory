﻿using System;
using System.Windows.Forms;

namespace RythmicQuebecInventory
{
    public partial class deleteWindow : Form
    {
        public deleteWindow()
        {
            InitializeComponent();
        }

        private void deleteWindow_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
