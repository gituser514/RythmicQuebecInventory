﻿using System;
using System.Windows.Forms;

namespace RythmicQuebecInventory
{
    public partial class Form8ModifyItem : Form
    {
        public Form8ModifyItem()
        {
            InitializeComponent();
        }

        private void ModifyWindow_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
