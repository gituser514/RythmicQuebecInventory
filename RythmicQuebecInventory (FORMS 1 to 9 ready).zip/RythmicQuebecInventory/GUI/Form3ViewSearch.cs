﻿using System.Windows.Forms;

namespace RythmicQuebecInventory
{
    public partial class Form3ViewSearch : Form
    {
        public Form3ViewSearch()
        {
            InitializeComponent();
        }

        private void dataGridViewViewSearch_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
