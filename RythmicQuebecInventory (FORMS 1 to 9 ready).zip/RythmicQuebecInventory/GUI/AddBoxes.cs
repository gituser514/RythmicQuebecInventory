﻿using System;
using System.Windows.Forms;

namespace RythmicQuebecInventory
{
    public partial class AddBoxes : Form
    {
        public AddBoxes()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
