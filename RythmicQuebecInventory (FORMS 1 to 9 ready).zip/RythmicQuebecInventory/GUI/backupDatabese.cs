﻿using System.Windows.Forms;

namespace RythmicQuebecInventory
{
    public partial class backupDatabese : Form
    {
        public backupDatabese()
        {
            InitializeComponent();
        }
    }
}
