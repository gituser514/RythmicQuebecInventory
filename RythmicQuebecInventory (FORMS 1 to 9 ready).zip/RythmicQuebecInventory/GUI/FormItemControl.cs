﻿using System.Windows.Forms;

namespace RythmicQuebecInventory.GUI
{
    public partial class FormItemControl : Form
    {
        public FormItemControl()
        {
            InitializeComponent();
        }
    }
}
