﻿using System;
using System.Windows.Forms;

namespace RythmicQuebecInventory
{
    public partial class Form6AddNewItems : Form
    {
        public Form6AddNewItems()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
