﻿namespace RythmicQuebecInventory {
    
    
    public partial class InventoryDBDataSet {
    }
}
namespace RythmicQuebecInventory {
    
    
    public partial class InventoryDBDataSet {
    }
}
