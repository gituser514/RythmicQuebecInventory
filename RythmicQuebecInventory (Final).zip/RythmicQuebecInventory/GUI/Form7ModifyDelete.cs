﻿using System.Windows.Forms;

namespace RythmicQuebecInventory
{
    public partial class Form7ModifyDelete : Form
    {
        public Form7ModifyDelete()
        {
            InitializeComponent();
        }
    }
}
