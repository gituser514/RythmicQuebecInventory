﻿using System;
using System.Windows.Forms;

namespace RythmicQuebecInventory
{
    public partial class Form11CreatQRCode : Form
    {
        public Form11CreatQRCode()
        {
            InitializeComponent();
            //insertComboItems();

        }

        private void selectBoxies_TextChanged(object sender, EventArgs e)
        {

        }

        private void creatQRCode_Load(object sender, EventArgs e)
        {

        }
    }
}
