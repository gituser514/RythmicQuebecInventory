﻿using System.Windows.Forms;

namespace RythmicQuebecInventory
{
    public partial class Form12BackupDatabese : Form
    {
        public Form12BackupDatabese()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, System.EventArgs e)
        {

        }
    }
}
