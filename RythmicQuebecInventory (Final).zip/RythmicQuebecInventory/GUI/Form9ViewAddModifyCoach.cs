﻿using System.Windows.Forms;

namespace RythmicQuebecInventory
{
    public partial class Form9ViewAddModifyCoach : Form
    {
        public Form9ViewAddModifyCoach()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
