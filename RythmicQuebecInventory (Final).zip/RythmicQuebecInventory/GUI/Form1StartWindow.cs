﻿using System;
using System.Windows.Forms;

namespace RythmicQuebecInventory
{
    public partial class Form1StartWindow : Form
    {
        public Form1StartWindow()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
