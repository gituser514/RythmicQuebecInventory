﻿using System;
using System.Windows.Forms;

namespace RythmicQuebecInventory
{
    public partial class Form10ViewAddModifyBoxes : Form
    {
        public Form10ViewAddModifyBoxes()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
