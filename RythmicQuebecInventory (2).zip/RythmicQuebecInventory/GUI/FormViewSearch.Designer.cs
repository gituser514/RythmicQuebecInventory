﻿namespace RythmicQuebecInventory
{
    partial class FormViewSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxFilterElements = new System.Windows.Forms.GroupBox();
            this.comboBoxInStock = new System.Windows.Forms.ComboBox();
            this.comboBoxBoxNumber = new System.Windows.Forms.ComboBox();
            this.textBoxQuantity = new System.Windows.Forms.TextBox();
            this.checkBoxJauneYellow = new System.Windows.Forms.CheckBox();
            this.checkBoxBrunBrown = new System.Windows.Forms.CheckBox();
            this.checkBoxAutreOther = new System.Windows.Forms.CheckBox();
            this.checkBoxOrGold = new System.Windows.Forms.CheckBox();
            this.checkBoxArgentSilver = new System.Windows.Forms.CheckBox();
            this.checkBoxMauve = new System.Windows.Forms.CheckBox();
            this.checkBoxBourgogneИгкпгтвн = new System.Windows.Forms.CheckBox();
            this.checkBoxBlancWhite = new System.Windows.Forms.CheckBox();
            this.checkBoxRose = new System.Windows.Forms.CheckBox();
            this.checkBoxBleueBlue = new System.Windows.Forms.CheckBox();
            this.checkBoxRougeRed = new System.Windows.Forms.CheckBox();
            this.checkBoxNoirBlack = new System.Windows.Forms.CheckBox();
            this.checkBox1516 = new System.Windows.Forms.CheckBox();
            this.checkBox1314 = new System.Windows.Forms.CheckBox();
            this.checkBoxL = new System.Windows.Forms.CheckBox();
            this.checkBoxM = new System.Windows.Forms.CheckBox();
            this.checkBoxS = new System.Windows.Forms.CheckBox();
            this.checkBox1112 = new System.Windows.Forms.CheckBox();
            this.checkBox78 = new System.Windows.Forms.CheckBox();
            this.checkBox34 = new System.Windows.Forms.CheckBox();
            this.checkBoxBiggerThan16 = new System.Windows.Forms.CheckBox();
            this.checkBox910 = new System.Windows.Forms.CheckBox();
            this.checkBox56 = new System.Windows.Forms.CheckBox();
            this.checkBoxLessThan3 = new System.Windows.Forms.CheckBox();
            this.checkBoxVaria = new System.Windows.Forms.CheckBox();
            this.checkBoxDecor = new System.Windows.Forms.CheckBox();
            this.checkBoxAccessoires = new System.Windows.Forms.CheckBox();
            this.checkBoxHautes = new System.Windows.Forms.CheckBox();
            this.checkBoxTShirts = new System.Windows.Forms.CheckBox();
            this.checkBoxJupesSkirts = new System.Windows.Forms.CheckBox();
            this.checkBoxHeadGear = new System.Windows.Forms.CheckBox();
            this.checkBoxBas = new System.Windows.Forms.CheckBox();
            this.checkBoxShorts = new System.Windows.Forms.CheckBox();
            this.checkBoxMailotsLeotards = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.labelQuantity = new System.Windows.Forms.Label();
            this.labelBoxNo = new System.Windows.Forms.Label();
            this.labelColor = new System.Windows.Forms.Label();
            this.labelSize = new System.Windows.Forms.Label();
            this.labelCategory = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxResults = new System.Windows.Forms.GroupBox();
            this.dataGridViewViewSearch = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ColumnImage = new System.Windows.Forms.DataGridViewImageColumn();
            this.ColumnItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnInStock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.admAccessClick = new System.Windows.Forms.Label();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.labelSearch = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.groupBoxFilterElements.SuspendLayout();
            this.groupBoxResults.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewViewSearch)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxFilterElements
            // 
            this.groupBoxFilterElements.BackColor = System.Drawing.Color.White;
            this.groupBoxFilterElements.Controls.Add(this.checkBox1);
            this.groupBoxFilterElements.Controls.Add(this.checkBox2);
            this.groupBoxFilterElements.Controls.Add(this.checkBox3);
            this.groupBoxFilterElements.Controls.Add(this.checkBox4);
            this.groupBoxFilterElements.Controls.Add(this.checkBox5);
            this.groupBoxFilterElements.Controls.Add(this.checkBox6);
            this.groupBoxFilterElements.Controls.Add(this.checkBox7);
            this.groupBoxFilterElements.Controls.Add(this.checkBox8);
            this.groupBoxFilterElements.Controls.Add(this.checkBox9);
            this.groupBoxFilterElements.Controls.Add(this.checkBox10);
            this.groupBoxFilterElements.Controls.Add(this.checkBox11);
            this.groupBoxFilterElements.Controls.Add(this.checkBox12);
            this.groupBoxFilterElements.Controls.Add(this.comboBoxInStock);
            this.groupBoxFilterElements.Controls.Add(this.comboBoxBoxNumber);
            this.groupBoxFilterElements.Controls.Add(this.textBoxQuantity);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxJauneYellow);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxBrunBrown);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxAutreOther);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxOrGold);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxArgentSilver);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxMauve);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxBourgogneИгкпгтвн);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxBlancWhite);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxRose);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxBleueBlue);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxRougeRed);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxNoirBlack);
            this.groupBoxFilterElements.Controls.Add(this.checkBox1516);
            this.groupBoxFilterElements.Controls.Add(this.checkBox1314);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxL);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxM);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxS);
            this.groupBoxFilterElements.Controls.Add(this.checkBox1112);
            this.groupBoxFilterElements.Controls.Add(this.checkBox78);
            this.groupBoxFilterElements.Controls.Add(this.checkBox34);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxBiggerThan16);
            this.groupBoxFilterElements.Controls.Add(this.checkBox910);
            this.groupBoxFilterElements.Controls.Add(this.checkBox56);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxLessThan3);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxVaria);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxDecor);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxAccessoires);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxHautes);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxTShirts);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxJupesSkirts);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxHeadGear);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxBas);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxShorts);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxMailotsLeotards);
            this.groupBoxFilterElements.Controls.Add(this.label3);
            this.groupBoxFilterElements.Controls.Add(this.labelQuantity);
            this.groupBoxFilterElements.Controls.Add(this.labelBoxNo);
            this.groupBoxFilterElements.Controls.Add(this.labelColor);
            this.groupBoxFilterElements.Controls.Add(this.labelSize);
            this.groupBoxFilterElements.Controls.Add(this.labelCategory);
            this.groupBoxFilterElements.Location = new System.Drawing.Point(0, 79);
            this.groupBoxFilterElements.Name = "groupBoxFilterElements";
            this.groupBoxFilterElements.Size = new System.Drawing.Size(300, 955);
            this.groupBoxFilterElements.TabIndex = 0;
            this.groupBoxFilterElements.TabStop = false;
            this.groupBoxFilterElements.Text = "Filteration";
            // 
            // comboBoxInStock
            // 
            this.comboBoxInStock.FormattingEnabled = true;
            this.comboBoxInStock.Location = new System.Drawing.Point(34, 773);
            this.comboBoxInStock.Name = "comboBoxInStock";
            this.comboBoxInStock.Size = new System.Drawing.Size(121, 24);
            this.comboBoxInStock.TabIndex = 43;
            // 
            // comboBoxBoxNumber
            // 
            this.comboBoxBoxNumber.FormattingEnabled = true;
            this.comboBoxBoxNumber.Location = new System.Drawing.Point(34, 836);
            this.comboBoxBoxNumber.Name = "comboBoxBoxNumber";
            this.comboBoxBoxNumber.Size = new System.Drawing.Size(121, 24);
            this.comboBoxBoxNumber.TabIndex = 41;
            // 
            // textBoxQuantity
            // 
            this.textBoxQuantity.Location = new System.Drawing.Point(34, 719);
            this.textBoxQuantity.Name = "textBoxQuantity";
            this.textBoxQuantity.Size = new System.Drawing.Size(100, 22);
            this.textBoxQuantity.TabIndex = 40;
            // 
            // checkBoxJauneYellow
            // 
            this.checkBoxJauneYellow.AutoSize = true;
            this.checkBoxJauneYellow.Location = new System.Drawing.Point(139, 434);
            this.checkBoxJauneYellow.Name = "checkBoxJauneYellow";
            this.checkBoxJauneYellow.Size = new System.Drawing.Size(66, 20);
            this.checkBoxJauneYellow.TabIndex = 39;
            this.checkBoxJauneYellow.Text = "Jaune";
            this.checkBoxJauneYellow.UseVisualStyleBackColor = true;
            // 
            // checkBoxBrunBrown
            // 
            this.checkBoxBrunBrown.AutoSize = true;
            this.checkBoxBrunBrown.Location = new System.Drawing.Point(6, 434);
            this.checkBoxBrunBrown.Name = "checkBoxBrunBrown";
            this.checkBoxBrunBrown.Size = new System.Drawing.Size(56, 20);
            this.checkBoxBrunBrown.TabIndex = 38;
            this.checkBoxBrunBrown.Text = "Brun";
            this.checkBoxBrunBrown.UseVisualStyleBackColor = true;
            // 
            // checkBoxAutreOther
            // 
            this.checkBoxAutreOther.AutoSize = true;
            this.checkBoxAutreOther.Location = new System.Drawing.Point(139, 479);
            this.checkBoxAutreOther.Name = "checkBoxAutreOther";
            this.checkBoxAutreOther.Size = new System.Drawing.Size(60, 20);
            this.checkBoxAutreOther.TabIndex = 37;
            this.checkBoxAutreOther.Text = "Autre";
            this.checkBoxAutreOther.UseVisualStyleBackColor = true;
            // 
            // checkBoxOrGold
            // 
            this.checkBoxOrGold.AutoSize = true;
            this.checkBoxOrGold.Location = new System.Drawing.Point(6, 479);
            this.checkBoxOrGold.Name = "checkBoxOrGold";
            this.checkBoxOrGold.Size = new System.Drawing.Size(43, 20);
            this.checkBoxOrGold.TabIndex = 36;
            this.checkBoxOrGold.Text = "Or";
            this.checkBoxOrGold.UseVisualStyleBackColor = true;
            // 
            // checkBoxArgentSilver
            // 
            this.checkBoxArgentSilver.AutoSize = true;
            this.checkBoxArgentSilver.Location = new System.Drawing.Point(139, 456);
            this.checkBoxArgentSilver.Name = "checkBoxArgentSilver";
            this.checkBoxArgentSilver.Size = new System.Drawing.Size(68, 20);
            this.checkBoxArgentSilver.TabIndex = 35;
            this.checkBoxArgentSilver.Text = "Argent";
            this.checkBoxArgentSilver.UseVisualStyleBackColor = true;
            // 
            // checkBoxMauve
            // 
            this.checkBoxMauve.AutoSize = true;
            this.checkBoxMauve.Location = new System.Drawing.Point(139, 410);
            this.checkBoxMauve.Name = "checkBoxMauve";
            this.checkBoxMauve.Size = new System.Drawing.Size(70, 20);
            this.checkBoxMauve.TabIndex = 34;
            this.checkBoxMauve.Text = "Mauve";
            this.checkBoxMauve.UseVisualStyleBackColor = true;
            // 
            // checkBoxBourgogneИгкпгтвн
            // 
            this.checkBoxBourgogneИгкпгтвн.AutoSize = true;
            this.checkBoxBourgogneИгкпгтвн.Location = new System.Drawing.Point(139, 385);
            this.checkBoxBourgogneИгкпгтвн.Name = "checkBoxBourgogneИгкпгтвн";
            this.checkBoxBourgogneИгкпгтвн.Size = new System.Drawing.Size(96, 20);
            this.checkBoxBourgogneИгкпгтвн.TabIndex = 33;
            this.checkBoxBourgogneИгкпгтвн.Text = "Bourgogne";
            this.checkBoxBourgogneИгкпгтвн.UseVisualStyleBackColor = true;
            // 
            // checkBoxBlancWhite
            // 
            this.checkBoxBlancWhite.AutoSize = true;
            this.checkBoxBlancWhite.Location = new System.Drawing.Point(139, 362);
            this.checkBoxBlancWhite.Name = "checkBoxBlancWhite";
            this.checkBoxBlancWhite.Size = new System.Drawing.Size(63, 20);
            this.checkBoxBlancWhite.TabIndex = 32;
            this.checkBoxBlancWhite.Text = "Blanc";
            this.checkBoxBlancWhite.UseVisualStyleBackColor = true;
            // 
            // checkBoxRose
            // 
            this.checkBoxRose.AutoSize = true;
            this.checkBoxRose.Location = new System.Drawing.Point(6, 456);
            this.checkBoxRose.Name = "checkBoxRose";
            this.checkBoxRose.Size = new System.Drawing.Size(62, 20);
            this.checkBoxRose.TabIndex = 31;
            this.checkBoxRose.Text = "Rose";
            this.checkBoxRose.UseVisualStyleBackColor = true;
            // 
            // checkBoxBleueBlue
            // 
            this.checkBoxBleueBlue.AutoSize = true;
            this.checkBoxBleueBlue.Location = new System.Drawing.Point(6, 410);
            this.checkBoxBleueBlue.Name = "checkBoxBleueBlue";
            this.checkBoxBleueBlue.Size = new System.Drawing.Size(64, 20);
            this.checkBoxBleueBlue.TabIndex = 30;
            this.checkBoxBleueBlue.Text = "Bleue";
            this.checkBoxBleueBlue.UseVisualStyleBackColor = true;
            // 
            // checkBoxRougeRed
            // 
            this.checkBoxRougeRed.AutoSize = true;
            this.checkBoxRougeRed.Location = new System.Drawing.Point(6, 385);
            this.checkBoxRougeRed.Name = "checkBoxRougeRed";
            this.checkBoxRougeRed.Size = new System.Drawing.Size(70, 20);
            this.checkBoxRougeRed.TabIndex = 29;
            this.checkBoxRougeRed.Text = "Rouge";
            this.checkBoxRougeRed.UseVisualStyleBackColor = true;
            // 
            // checkBoxNoirBlack
            // 
            this.checkBoxNoirBlack.AutoSize = true;
            this.checkBoxNoirBlack.Location = new System.Drawing.Point(6, 362);
            this.checkBoxNoirBlack.Name = "checkBoxNoirBlack";
            this.checkBoxNoirBlack.Size = new System.Drawing.Size(54, 20);
            this.checkBoxNoirBlack.TabIndex = 28;
            this.checkBoxNoirBlack.Text = "Noir";
            this.checkBoxNoirBlack.UseVisualStyleBackColor = true;
            // 
            // checkBox1516
            // 
            this.checkBox1516.AutoSize = true;
            this.checkBox1516.Location = new System.Drawing.Point(139, 262);
            this.checkBox1516.Name = "checkBox1516";
            this.checkBox1516.Size = new System.Drawing.Size(67, 20);
            this.checkBox1516.TabIndex = 27;
            this.checkBox1516.Text = "15 - 16";
            this.checkBox1516.UseVisualStyleBackColor = true;
            // 
            // checkBox1314
            // 
            this.checkBox1314.AutoSize = true;
            this.checkBox1314.Location = new System.Drawing.Point(6, 262);
            this.checkBox1314.Name = "checkBox1314";
            this.checkBox1314.Size = new System.Drawing.Size(67, 20);
            this.checkBox1314.TabIndex = 26;
            this.checkBox1314.Text = "13 - 14";
            this.checkBox1314.UseVisualStyleBackColor = true;
            // 
            // checkBoxL
            // 
            this.checkBoxL.AutoSize = true;
            this.checkBoxL.Location = new System.Drawing.Point(139, 307);
            this.checkBoxL.Name = "checkBoxL";
            this.checkBoxL.Size = new System.Drawing.Size(36, 20);
            this.checkBoxL.TabIndex = 25;
            this.checkBoxL.Text = "L";
            this.checkBoxL.UseVisualStyleBackColor = true;
            // 
            // checkBoxM
            // 
            this.checkBoxM.AutoSize = true;
            this.checkBoxM.Location = new System.Drawing.Point(6, 307);
            this.checkBoxM.Name = "checkBoxM";
            this.checkBoxM.Size = new System.Drawing.Size(40, 20);
            this.checkBoxM.TabIndex = 24;
            this.checkBoxM.Text = "M";
            this.checkBoxM.UseVisualStyleBackColor = true;
            // 
            // checkBoxS
            // 
            this.checkBoxS.AutoSize = true;
            this.checkBoxS.Location = new System.Drawing.Point(139, 284);
            this.checkBoxS.Name = "checkBoxS";
            this.checkBoxS.Size = new System.Drawing.Size(38, 20);
            this.checkBoxS.TabIndex = 23;
            this.checkBoxS.Text = "S";
            this.checkBoxS.UseVisualStyleBackColor = true;
            // 
            // checkBox1112
            // 
            this.checkBox1112.AutoSize = true;
            this.checkBox1112.Location = new System.Drawing.Point(139, 238);
            this.checkBox1112.Name = "checkBox1112";
            this.checkBox1112.Size = new System.Drawing.Size(67, 20);
            this.checkBox1112.TabIndex = 22;
            this.checkBox1112.Text = "11 - 12";
            this.checkBox1112.UseVisualStyleBackColor = true;
            // 
            // checkBox78
            // 
            this.checkBox78.AutoSize = true;
            this.checkBox78.Location = new System.Drawing.Point(139, 213);
            this.checkBox78.Name = "checkBox78";
            this.checkBox78.Size = new System.Drawing.Size(53, 20);
            this.checkBox78.TabIndex = 21;
            this.checkBox78.Text = "7 - 8";
            this.checkBox78.UseVisualStyleBackColor = true;
            // 
            // checkBox34
            // 
            this.checkBox34.AutoSize = true;
            this.checkBox34.Location = new System.Drawing.Point(139, 190);
            this.checkBox34.Name = "checkBox34";
            this.checkBox34.Size = new System.Drawing.Size(53, 20);
            this.checkBox34.TabIndex = 20;
            this.checkBox34.Text = "3 - 4";
            this.checkBox34.UseVisualStyleBackColor = true;
            // 
            // checkBoxBiggerThan16
            // 
            this.checkBoxBiggerThan16.AutoSize = true;
            this.checkBoxBiggerThan16.Location = new System.Drawing.Point(6, 284);
            this.checkBoxBiggerThan16.Name = "checkBoxBiggerThan16";
            this.checkBoxBiggerThan16.Size = new System.Drawing.Size(53, 20);
            this.checkBoxBiggerThan16.TabIndex = 19;
            this.checkBoxBiggerThan16.Text = "16 >";
            this.checkBoxBiggerThan16.UseVisualStyleBackColor = true;
            // 
            // checkBox910
            // 
            this.checkBox910.AutoSize = true;
            this.checkBox910.Location = new System.Drawing.Point(6, 238);
            this.checkBox910.Name = "checkBox910";
            this.checkBox910.Size = new System.Drawing.Size(63, 20);
            this.checkBox910.TabIndex = 18;
            this.checkBox910.Text = "9 - 10 ";
            this.checkBox910.UseVisualStyleBackColor = true;
            // 
            // checkBox56
            // 
            this.checkBox56.AutoSize = true;
            this.checkBox56.Location = new System.Drawing.Point(6, 213);
            this.checkBox56.Name = "checkBox56";
            this.checkBox56.Size = new System.Drawing.Size(56, 20);
            this.checkBox56.TabIndex = 17;
            this.checkBox56.Text = "5 - 6 ";
            this.checkBox56.UseVisualStyleBackColor = true;
            // 
            // checkBoxLessThan3
            // 
            this.checkBoxLessThan3.AutoSize = true;
            this.checkBoxLessThan3.Location = new System.Drawing.Point(6, 190);
            this.checkBoxLessThan3.Name = "checkBoxLessThan3";
            this.checkBoxLessThan3.Size = new System.Drawing.Size(46, 20);
            this.checkBoxLessThan3.TabIndex = 16;
            this.checkBoxLessThan3.Text = "< 3";
            this.checkBoxLessThan3.UseVisualStyleBackColor = true;
            // 
            // checkBoxVaria
            // 
            this.checkBoxVaria.AutoSize = true;
            this.checkBoxVaria.Location = new System.Drawing.Point(139, 136);
            this.checkBoxVaria.Name = "checkBoxVaria";
            this.checkBoxVaria.Size = new System.Drawing.Size(61, 20);
            this.checkBoxVaria.TabIndex = 15;
            this.checkBoxVaria.Text = "Varia";
            this.checkBoxVaria.UseVisualStyleBackColor = true;
            // 
            // checkBoxDecor
            // 
            this.checkBoxDecor.AutoSize = true;
            this.checkBoxDecor.Location = new System.Drawing.Point(6, 136);
            this.checkBoxDecor.Name = "checkBoxDecor";
            this.checkBoxDecor.Size = new System.Drawing.Size(66, 20);
            this.checkBoxDecor.TabIndex = 14;
            this.checkBoxDecor.Text = "Décor";
            this.checkBoxDecor.UseVisualStyleBackColor = true;
            // 
            // checkBoxAccessoires
            // 
            this.checkBoxAccessoires.AutoSize = true;
            this.checkBoxAccessoires.Location = new System.Drawing.Point(139, 113);
            this.checkBoxAccessoires.Name = "checkBoxAccessoires";
            this.checkBoxAccessoires.Size = new System.Drawing.Size(104, 20);
            this.checkBoxAccessoires.TabIndex = 13;
            this.checkBoxAccessoires.Text = "Accessoires";
            this.checkBoxAccessoires.UseVisualStyleBackColor = true;
            // 
            // checkBoxHautes
            // 
            this.checkBoxHautes.AutoSize = true;
            this.checkBoxHautes.Location = new System.Drawing.Point(139, 90);
            this.checkBoxHautes.Name = "checkBoxHautes";
            this.checkBoxHautes.Size = new System.Drawing.Size(72, 20);
            this.checkBoxHautes.TabIndex = 12;
            this.checkBoxHautes.Text = "Hautes";
            this.checkBoxHautes.UseVisualStyleBackColor = true;
            // 
            // checkBoxTShirts
            // 
            this.checkBoxTShirts.AutoSize = true;
            this.checkBoxTShirts.Location = new System.Drawing.Point(139, 65);
            this.checkBoxTShirts.Name = "checkBoxTShirts";
            this.checkBoxTShirts.Size = new System.Drawing.Size(75, 20);
            this.checkBoxTShirts.TabIndex = 11;
            this.checkBoxTShirts.Text = "T-Shirts";
            this.checkBoxTShirts.UseVisualStyleBackColor = true;
            // 
            // checkBoxJupesSkirts
            // 
            this.checkBoxJupesSkirts.AutoSize = true;
            this.checkBoxJupesSkirts.Location = new System.Drawing.Point(139, 42);
            this.checkBoxJupesSkirts.Name = "checkBoxJupesSkirts";
            this.checkBoxJupesSkirts.Size = new System.Drawing.Size(66, 20);
            this.checkBoxJupesSkirts.TabIndex = 10;
            this.checkBoxJupesSkirts.Text = "Jupes";
            this.checkBoxJupesSkirts.UseVisualStyleBackColor = true;
            // 
            // checkBoxHeadGear
            // 
            this.checkBoxHeadGear.AutoSize = true;
            this.checkBoxHeadGear.Location = new System.Drawing.Point(6, 113);
            this.checkBoxHeadGear.Name = "checkBoxHeadGear";
            this.checkBoxHeadGear.Size = new System.Drawing.Size(115, 20);
            this.checkBoxHeadGear.TabIndex = 9;
            this.checkBoxHeadGear.Text = "Pièces de tête";
            this.checkBoxHeadGear.UseVisualStyleBackColor = true;
            // 
            // checkBoxBas
            // 
            this.checkBoxBas.AutoSize = true;
            this.checkBoxBas.Location = new System.Drawing.Point(6, 90);
            this.checkBoxBas.Name = "checkBoxBas";
            this.checkBoxBas.Size = new System.Drawing.Size(53, 20);
            this.checkBoxBas.TabIndex = 8;
            this.checkBoxBas.Text = "Bas";
            this.checkBoxBas.UseVisualStyleBackColor = true;
            // 
            // checkBoxShorts
            // 
            this.checkBoxShorts.AutoSize = true;
            this.checkBoxShorts.Location = new System.Drawing.Point(6, 65);
            this.checkBoxShorts.Name = "checkBoxShorts";
            this.checkBoxShorts.Size = new System.Drawing.Size(67, 20);
            this.checkBoxShorts.TabIndex = 7;
            this.checkBoxShorts.Text = "Shorts";
            this.checkBoxShorts.UseVisualStyleBackColor = true;
            // 
            // checkBoxMailotsLeotards
            // 
            this.checkBoxMailotsLeotards.AutoSize = true;
            this.checkBoxMailotsLeotards.Location = new System.Drawing.Point(6, 42);
            this.checkBoxMailotsLeotards.Name = "checkBoxMailotsLeotards";
            this.checkBoxMailotsLeotards.Size = new System.Drawing.Size(72, 20);
            this.checkBoxMailotsLeotards.TabIndex = 6;
            this.checkBoxMailotsLeotards.Text = "Mailots";
            this.checkBoxMailotsLeotards.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 754);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "EN STOCK";
            // 
            // labelQuantity
            // 
            this.labelQuantity.AutoSize = true;
            this.labelQuantity.Location = new System.Drawing.Point(34, 700);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new System.Drawing.Size(76, 16);
            this.labelQuantity.TabIndex = 4;
            this.labelQuantity.Text = "QUANTITÉ";
            // 
            // labelBoxNo
            // 
            this.labelBoxNo.AutoSize = true;
            this.labelBoxNo.Location = new System.Drawing.Point(34, 817);
            this.labelBoxNo.Name = "labelBoxNo";
            this.labelBoxNo.Size = new System.Drawing.Size(68, 16);
            this.labelBoxNo.TabIndex = 3;
            this.labelBoxNo.Text = "BOÎTE No";
            // 
            // labelColor
            // 
            this.labelColor.AutoSize = true;
            this.labelColor.Location = new System.Drawing.Point(31, 343);
            this.labelColor.Name = "labelColor";
            this.labelColor.Size = new System.Drawing.Size(72, 16);
            this.labelColor.TabIndex = 2;
            this.labelColor.Text = "COULEUR";
            // 
            // labelSize
            // 
            this.labelSize.AutoSize = true;
            this.labelSize.Location = new System.Drawing.Point(31, 170);
            this.labelSize.Name = "labelSize";
            this.labelSize.Size = new System.Drawing.Size(51, 16);
            this.labelSize.TabIndex = 1;
            this.labelSize.Text = "TAILLE";
            // 
            // labelCategory
            // 
            this.labelCategory.AutoSize = true;
            this.labelCategory.Location = new System.Drawing.Point(31, 23);
            this.labelCategory.Name = "labelCategory";
            this.labelCategory.Size = new System.Drawing.Size(85, 16);
            this.labelCategory.TabIndex = 0;
            this.labelCategory.Text = "CATÉGORIE";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1648, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(10, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = " ";
            // 
            // groupBoxResults
            // 
            this.groupBoxResults.BackColor = System.Drawing.Color.White;
            this.groupBoxResults.Controls.Add(this.dataGridViewViewSearch);
            this.groupBoxResults.Location = new System.Drawing.Point(306, 79);
            this.groupBoxResults.Name = "groupBoxResults";
            this.groupBoxResults.Size = new System.Drawing.Size(1600, 955);
            this.groupBoxResults.TabIndex = 4;
            this.groupBoxResults.TabStop = false;
            this.groupBoxResults.Text = "Résultats";
            // 
            // dataGridViewViewSearch
            // 
            this.dataGridViewViewSearch.AllowUserToOrderColumns = true;
            this.dataGridViewViewSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewViewSearch.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.ColumnImage,
            this.ColumnItemID,
            this.ColumnInStock,
            this.ColumnName,
            this.ColumnDescription});
            this.dataGridViewViewSearch.Location = new System.Drawing.Point(6, 23);
            this.dataGridViewViewSearch.Name = "dataGridViewViewSearch";
            this.dataGridViewViewSearch.RowHeadersWidth = 51;
            this.dataGridViewViewSearch.RowTemplate.Height = 24;
            this.dataGridViewViewSearch.Size = new System.Drawing.Size(1588, 926);
            this.dataGridViewViewSearch.TabIndex = 3;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column1.HeaderText = "Сhoisir";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Width = 54;
            // 
            // ColumnImage
            // 
            this.ColumnImage.HeaderText = "Image";
            this.ColumnImage.MinimumWidth = 6;
            this.ColumnImage.Name = "ColumnImage";
            this.ColumnImage.Width = 200;
            // 
            // ColumnItemID
            // 
            this.ColumnItemID.HeaderText = "ItemID";
            this.ColumnItemID.MinimumWidth = 6;
            this.ColumnItemID.Name = "ColumnItemID";
            this.ColumnItemID.Width = 125;
            // 
            // ColumnInStock
            // 
            this.ColumnInStock.HeaderText = "En Stock ";
            this.ColumnInStock.MinimumWidth = 6;
            this.ColumnInStock.Name = "ColumnInStock";
            this.ColumnInStock.Width = 125;
            // 
            // ColumnName
            // 
            this.ColumnName.HeaderText = "Nom";
            this.ColumnName.MinimumWidth = 6;
            this.ColumnName.Name = "ColumnName";
            this.ColumnName.Width = 125;
            // 
            // ColumnDescription
            // 
            this.ColumnDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColumnDescription.HeaderText = "Description";
            this.ColumnDescription.MinimumWidth = 6;
            this.ColumnDescription.Name = "ColumnDescription";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Silver;
            this.label2.Location = new System.Drawing.Point(18, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(232, 22);
            this.label2.TabIndex = 5;
            this.label2.Text = "VOIR ET RECHERCHER";
            // 
            // admAccessClick
            // 
            this.admAccessClick.AutoSize = true;
            this.admAccessClick.BackColor = System.Drawing.Color.Black;
            this.admAccessClick.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admAccessClick.ForeColor = System.Drawing.Color.Silver;
            this.admAccessClick.Location = new System.Drawing.Point(1698, 30);
            this.admAccessClick.Name = "admAccessClick";
            this.admAccessClick.Size = new System.Drawing.Size(284, 25);
            this.admAccessClick.TabIndex = 2;
            this.admAccessClick.Text = "ACCÈS ADMINISTRATEUR";
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(461, 45);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(260, 22);
            this.textBoxSearch.TabIndex = 7;
            // 
            // labelSearch
            // 
            this.labelSearch.AutoSize = true;
            this.labelSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearch.ForeColor = System.Drawing.Color.Silver;
            this.labelSearch.Location = new System.Drawing.Point(308, 45);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(147, 22);
            this.labelSearch.TabIndex = 6;
            this.labelSearch.Text = "RECHERCHER";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(139, 574);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(66, 20);
            this.checkBox1.TabIndex = 55;
            this.checkBox1.Text = "Jaune";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(6, 574);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(56, 20);
            this.checkBox2.TabIndex = 54;
            this.checkBox2.Text = "Brun";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(139, 619);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(60, 20);
            this.checkBox3.TabIndex = 53;
            this.checkBox3.Text = "Autre";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(6, 619);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(43, 20);
            this.checkBox4.TabIndex = 52;
            this.checkBox4.Text = "Or";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(139, 596);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(68, 20);
            this.checkBox5.TabIndex = 51;
            this.checkBox5.Text = "Argent";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(139, 550);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(70, 20);
            this.checkBox6.TabIndex = 50;
            this.checkBox6.Text = "Mauve";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(139, 525);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(74, 20);
            this.checkBox7.TabIndex = 49;
            this.checkBox7.Text = "Orange";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(139, 502);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(63, 20);
            this.checkBox8.TabIndex = 48;
            this.checkBox8.Text = "Blanc";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(6, 596);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(62, 20);
            this.checkBox9.TabIndex = 47;
            this.checkBox9.Text = "Rose";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(6, 550);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(64, 20);
            this.checkBox10.TabIndex = 46;
            this.checkBox10.Text = "Bleue";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(6, 525);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(70, 20);
            this.checkBox11.TabIndex = 45;
            this.checkBox11.Text = "Rouge";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(6, 502);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(54, 20);
            this.checkBox12.TabIndex = 44;
            this.checkBox12.Text = "Noir";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // FormViewSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1902, 1032);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.labelSearch);
            this.Controls.Add(this.admAccessClick);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBoxResults);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBoxFilterElements);
            this.Name = "FormViewSearch";
            this.Text = "Form1";
            this.groupBoxFilterElements.ResumeLayout(false);
            this.groupBoxFilterElements.PerformLayout();
            this.groupBoxResults.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewViewSearch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxFilterElements;
        private System.Windows.Forms.Label labelQuantity;
        private System.Windows.Forms.Label labelBoxNo;
        private System.Windows.Forms.Label labelColor;
        private System.Windows.Forms.Label labelSize;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBoxResults;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBoxVaria;
        private System.Windows.Forms.CheckBox checkBoxDecor;
        private System.Windows.Forms.CheckBox checkBoxAccessoires;
        private System.Windows.Forms.CheckBox checkBoxHautes;
        private System.Windows.Forms.CheckBox checkBoxTShirts;
        private System.Windows.Forms.CheckBox checkBoxJupesSkirts;
        private System.Windows.Forms.CheckBox checkBoxHeadGear;
        private System.Windows.Forms.CheckBox checkBoxBas;
        private System.Windows.Forms.CheckBox checkBoxShorts;
        private System.Windows.Forms.CheckBox checkBoxMailotsLeotards;
        private System.Windows.Forms.CheckBox checkBox1516;
        private System.Windows.Forms.CheckBox checkBox1314;
        private System.Windows.Forms.CheckBox checkBoxL;
        private System.Windows.Forms.CheckBox checkBoxM;
        private System.Windows.Forms.CheckBox checkBoxS;
        private System.Windows.Forms.CheckBox checkBox1112;
        private System.Windows.Forms.CheckBox checkBox78;
        private System.Windows.Forms.CheckBox checkBox34;
        private System.Windows.Forms.CheckBox checkBoxBiggerThan16;
        private System.Windows.Forms.CheckBox checkBox910;
        private System.Windows.Forms.CheckBox checkBox56;
        private System.Windows.Forms.CheckBox checkBoxLessThan3;
        private System.Windows.Forms.CheckBox checkBoxJauneYellow;
        private System.Windows.Forms.CheckBox checkBoxBrunBrown;
        private System.Windows.Forms.CheckBox checkBoxAutreOther;
        private System.Windows.Forms.CheckBox checkBoxOrGold;
        private System.Windows.Forms.CheckBox checkBoxArgentSilver;
        private System.Windows.Forms.CheckBox checkBoxMauve;
        private System.Windows.Forms.CheckBox checkBoxBourgogneИгкпгтвн;
        private System.Windows.Forms.CheckBox checkBoxBlancWhite;
        private System.Windows.Forms.CheckBox checkBoxRose;
        private System.Windows.Forms.CheckBox checkBoxBleueBlue;
        private System.Windows.Forms.CheckBox checkBoxRougeRed;
        private System.Windows.Forms.CheckBox checkBoxNoirBlack;
        private System.Windows.Forms.ComboBox comboBoxBoxNumber;
        private System.Windows.Forms.TextBox textBoxQuantity;
        private System.Windows.Forms.Label admAccessClick;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Label labelSearch;
        private System.Windows.Forms.ComboBox comboBoxInStock;
        private System.Windows.Forms.DataGridView dataGridViewViewSearch;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column1;
        private System.Windows.Forms.DataGridViewImageColumn ColumnImage;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnItemID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnInStock;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDescription;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
    }
}

