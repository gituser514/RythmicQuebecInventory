﻿namespace RythmicQuebecInventory.GUI
{
    partial class FormViewSearchTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBoxInStock = new System.Windows.Forms.TextBox();
            this.comboBoxBoxNumber = new System.Windows.Forms.ComboBox();
            this.textBoxQuantity = new System.Windows.Forms.TextBox();
            this.checkBoxJauneYellow = new System.Windows.Forms.CheckBox();
            this.checkBoxBrunBrown = new System.Windows.Forms.CheckBox();
            this.checkBoxAutreOther = new System.Windows.Forms.CheckBox();
            this.checkBoxOrGold = new System.Windows.Forms.CheckBox();
            this.checkBoxArgentSilver = new System.Windows.Forms.CheckBox();
            this.checkBoxMauve = new System.Windows.Forms.CheckBox();
            this.checkBoxOrange = new System.Windows.Forms.CheckBox();
            this.checkBoxBlancWhite = new System.Windows.Forms.CheckBox();
            this.checkBoxRose = new System.Windows.Forms.CheckBox();
            this.checkBoxBleueBlue = new System.Windows.Forms.CheckBox();
            this.checkBoxRougeRed = new System.Windows.Forms.CheckBox();
            this.checkBoxNoirBlack = new System.Windows.Forms.CheckBox();
            this.checkBox1516 = new System.Windows.Forms.CheckBox();
            this.checkBox1314 = new System.Windows.Forms.CheckBox();
            this.checkBoxL = new System.Windows.Forms.CheckBox();
            this.checkBoxM = new System.Windows.Forms.CheckBox();
            this.checkBoxS = new System.Windows.Forms.CheckBox();
            this.checkBox1112 = new System.Windows.Forms.CheckBox();
            this.checkBox78 = new System.Windows.Forms.CheckBox();
            this.checkBox34 = new System.Windows.Forms.CheckBox();
            this.admAccessClick = new System.Windows.Forms.Label();
            this.groupBoxResults = new System.Windows.Forms.GroupBox();
            this.checkBoxBiggerThan16 = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxFilterElements = new System.Windows.Forms.GroupBox();
            this.checkBox910 = new System.Windows.Forms.CheckBox();
            this.checkBox56 = new System.Windows.Forms.CheckBox();
            this.checkBoxLessThan3 = new System.Windows.Forms.CheckBox();
            this.checkBoxVaria = new System.Windows.Forms.CheckBox();
            this.checkBoxDecor = new System.Windows.Forms.CheckBox();
            this.checkBoxAccessoires = new System.Windows.Forms.CheckBox();
            this.checkBoxHautes = new System.Windows.Forms.CheckBox();
            this.checkBoxTShirts = new System.Windows.Forms.CheckBox();
            this.checkBoxJupesSkirts = new System.Windows.Forms.CheckBox();
            this.checkBoxHeadGear = new System.Windows.Forms.CheckBox();
            this.checkBoxBas = new System.Windows.Forms.CheckBox();
            this.checkBoxShorts = new System.Windows.Forms.CheckBox();
            this.checkBoxMailotsLeotards = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.labelQuantity = new System.Windows.Forms.Label();
            this.labelBoxNo = new System.Windows.Forms.Label();
            this.labelColor = new System.Windows.Forms.Label();
            this.labelSize = new System.Windows.Forms.Label();
            this.labelCategory = new System.Windows.Forms.Label();
            this.labelSearch = new System.Windows.Forms.Label();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBoxResults.SuspendLayout();
            this.groupBoxFilterElements.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1646, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(10, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = " ";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.checkBox1);
            this.flowLayoutPanel1.Controls.Add(this.pictureBox1);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(6, 21);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1588, 928);
            this.flowLayoutPanel1.TabIndex = 2;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(3, 3);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(18, 17);
            this.checkBox1.TabIndex = 3;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(27, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 150);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // textBoxInStock
            // 
            this.textBoxInStock.Location = new System.Drawing.Point(38, 597);
            this.textBoxInStock.Name = "textBoxInStock";
            this.textBoxInStock.Size = new System.Drawing.Size(100, 22);
            this.textBoxInStock.TabIndex = 42;
            // 
            // comboBoxBoxNumber
            // 
            this.comboBoxBoxNumber.FormattingEnabled = true;
            this.comboBoxBoxNumber.Location = new System.Drawing.Point(38, 660);
            this.comboBoxBoxNumber.Name = "comboBoxBoxNumber";
            this.comboBoxBoxNumber.Size = new System.Drawing.Size(121, 24);
            this.comboBoxBoxNumber.TabIndex = 41;
            // 
            // textBoxQuantity
            // 
            this.textBoxQuantity.Location = new System.Drawing.Point(34, 533);
            this.textBoxQuantity.Name = "textBoxQuantity";
            this.textBoxQuantity.Size = new System.Drawing.Size(100, 22);
            this.textBoxQuantity.TabIndex = 40;
            // 
            // checkBoxJauneYellow
            // 
            this.checkBoxJauneYellow.AutoSize = true;
            this.checkBoxJauneYellow.Location = new System.Drawing.Point(139, 434);
            this.checkBoxJauneYellow.Name = "checkBoxJauneYellow";
            this.checkBoxJauneYellow.Size = new System.Drawing.Size(66, 20);
            this.checkBoxJauneYellow.TabIndex = 39;
            this.checkBoxJauneYellow.Text = "Jaune";
            this.checkBoxJauneYellow.UseVisualStyleBackColor = true;
            // 
            // checkBoxBrunBrown
            // 
            this.checkBoxBrunBrown.AutoSize = true;
            this.checkBoxBrunBrown.Location = new System.Drawing.Point(6, 434);
            this.checkBoxBrunBrown.Name = "checkBoxBrunBrown";
            this.checkBoxBrunBrown.Size = new System.Drawing.Size(56, 20);
            this.checkBoxBrunBrown.TabIndex = 38;
            this.checkBoxBrunBrown.Text = "Brun";
            this.checkBoxBrunBrown.UseVisualStyleBackColor = true;
            // 
            // checkBoxAutreOther
            // 
            this.checkBoxAutreOther.AutoSize = true;
            this.checkBoxAutreOther.Location = new System.Drawing.Point(139, 479);
            this.checkBoxAutreOther.Name = "checkBoxAutreOther";
            this.checkBoxAutreOther.Size = new System.Drawing.Size(60, 20);
            this.checkBoxAutreOther.TabIndex = 37;
            this.checkBoxAutreOther.Text = "Autre";
            this.checkBoxAutreOther.UseVisualStyleBackColor = true;
            // 
            // checkBoxOrGold
            // 
            this.checkBoxOrGold.AutoSize = true;
            this.checkBoxOrGold.Location = new System.Drawing.Point(6, 479);
            this.checkBoxOrGold.Name = "checkBoxOrGold";
            this.checkBoxOrGold.Size = new System.Drawing.Size(43, 20);
            this.checkBoxOrGold.TabIndex = 36;
            this.checkBoxOrGold.Text = "Or";
            this.checkBoxOrGold.UseVisualStyleBackColor = true;
            // 
            // checkBoxArgentSilver
            // 
            this.checkBoxArgentSilver.AutoSize = true;
            this.checkBoxArgentSilver.Location = new System.Drawing.Point(139, 456);
            this.checkBoxArgentSilver.Name = "checkBoxArgentSilver";
            this.checkBoxArgentSilver.Size = new System.Drawing.Size(68, 20);
            this.checkBoxArgentSilver.TabIndex = 35;
            this.checkBoxArgentSilver.Text = "Argent";
            this.checkBoxArgentSilver.UseVisualStyleBackColor = true;
            // 
            // checkBoxMauve
            // 
            this.checkBoxMauve.AutoSize = true;
            this.checkBoxMauve.Location = new System.Drawing.Point(139, 410);
            this.checkBoxMauve.Name = "checkBoxMauve";
            this.checkBoxMauve.Size = new System.Drawing.Size(70, 20);
            this.checkBoxMauve.TabIndex = 34;
            this.checkBoxMauve.Text = "Mauve";
            this.checkBoxMauve.UseVisualStyleBackColor = true;
            // 
            // checkBoxOrange
            // 
            this.checkBoxOrange.AutoSize = true;
            this.checkBoxOrange.Location = new System.Drawing.Point(139, 385);
            this.checkBoxOrange.Name = "checkBoxOrange";
            this.checkBoxOrange.Size = new System.Drawing.Size(74, 20);
            this.checkBoxOrange.TabIndex = 33;
            this.checkBoxOrange.Text = "Orange";
            this.checkBoxOrange.UseVisualStyleBackColor = true;
            // 
            // checkBoxBlancWhite
            // 
            this.checkBoxBlancWhite.AutoSize = true;
            this.checkBoxBlancWhite.Location = new System.Drawing.Point(139, 362);
            this.checkBoxBlancWhite.Name = "checkBoxBlancWhite";
            this.checkBoxBlancWhite.Size = new System.Drawing.Size(63, 20);
            this.checkBoxBlancWhite.TabIndex = 32;
            this.checkBoxBlancWhite.Text = "Blanc";
            this.checkBoxBlancWhite.UseVisualStyleBackColor = true;
            // 
            // checkBoxRose
            // 
            this.checkBoxRose.AutoSize = true;
            this.checkBoxRose.Location = new System.Drawing.Point(6, 456);
            this.checkBoxRose.Name = "checkBoxRose";
            this.checkBoxRose.Size = new System.Drawing.Size(62, 20);
            this.checkBoxRose.TabIndex = 31;
            this.checkBoxRose.Text = "Rose";
            this.checkBoxRose.UseVisualStyleBackColor = true;
            // 
            // checkBoxBleueBlue
            // 
            this.checkBoxBleueBlue.AutoSize = true;
            this.checkBoxBleueBlue.Location = new System.Drawing.Point(6, 410);
            this.checkBoxBleueBlue.Name = "checkBoxBleueBlue";
            this.checkBoxBleueBlue.Size = new System.Drawing.Size(64, 20);
            this.checkBoxBleueBlue.TabIndex = 30;
            this.checkBoxBleueBlue.Text = "Bleue";
            this.checkBoxBleueBlue.UseVisualStyleBackColor = true;
            // 
            // checkBoxRougeRed
            // 
            this.checkBoxRougeRed.AutoSize = true;
            this.checkBoxRougeRed.Location = new System.Drawing.Point(6, 385);
            this.checkBoxRougeRed.Name = "checkBoxRougeRed";
            this.checkBoxRougeRed.Size = new System.Drawing.Size(70, 20);
            this.checkBoxRougeRed.TabIndex = 29;
            this.checkBoxRougeRed.Text = "Rouge";
            this.checkBoxRougeRed.UseVisualStyleBackColor = true;
            // 
            // checkBoxNoirBlack
            // 
            this.checkBoxNoirBlack.AutoSize = true;
            this.checkBoxNoirBlack.Location = new System.Drawing.Point(6, 362);
            this.checkBoxNoirBlack.Name = "checkBoxNoirBlack";
            this.checkBoxNoirBlack.Size = new System.Drawing.Size(54, 20);
            this.checkBoxNoirBlack.TabIndex = 28;
            this.checkBoxNoirBlack.Text = "Noir";
            this.checkBoxNoirBlack.UseVisualStyleBackColor = true;
            // 
            // checkBox1516
            // 
            this.checkBox1516.AutoSize = true;
            this.checkBox1516.Location = new System.Drawing.Point(139, 262);
            this.checkBox1516.Name = "checkBox1516";
            this.checkBox1516.Size = new System.Drawing.Size(67, 20);
            this.checkBox1516.TabIndex = 27;
            this.checkBox1516.Text = "15 - 16";
            this.checkBox1516.UseVisualStyleBackColor = true;
            // 
            // checkBox1314
            // 
            this.checkBox1314.AutoSize = true;
            this.checkBox1314.Location = new System.Drawing.Point(6, 262);
            this.checkBox1314.Name = "checkBox1314";
            this.checkBox1314.Size = new System.Drawing.Size(67, 20);
            this.checkBox1314.TabIndex = 26;
            this.checkBox1314.Text = "13 - 14";
            this.checkBox1314.UseVisualStyleBackColor = true;
            // 
            // checkBoxL
            // 
            this.checkBoxL.AutoSize = true;
            this.checkBoxL.Location = new System.Drawing.Point(139, 307);
            this.checkBoxL.Name = "checkBoxL";
            this.checkBoxL.Size = new System.Drawing.Size(36, 20);
            this.checkBoxL.TabIndex = 25;
            this.checkBoxL.Text = "L";
            this.checkBoxL.UseVisualStyleBackColor = true;
            // 
            // checkBoxM
            // 
            this.checkBoxM.AutoSize = true;
            this.checkBoxM.Location = new System.Drawing.Point(6, 307);
            this.checkBoxM.Name = "checkBoxM";
            this.checkBoxM.Size = new System.Drawing.Size(40, 20);
            this.checkBoxM.TabIndex = 24;
            this.checkBoxM.Text = "M";
            this.checkBoxM.UseVisualStyleBackColor = true;
            // 
            // checkBoxS
            // 
            this.checkBoxS.AutoSize = true;
            this.checkBoxS.Location = new System.Drawing.Point(139, 284);
            this.checkBoxS.Name = "checkBoxS";
            this.checkBoxS.Size = new System.Drawing.Size(38, 20);
            this.checkBoxS.TabIndex = 23;
            this.checkBoxS.Text = "S";
            this.checkBoxS.UseVisualStyleBackColor = true;
            // 
            // checkBox1112
            // 
            this.checkBox1112.AutoSize = true;
            this.checkBox1112.Location = new System.Drawing.Point(139, 238);
            this.checkBox1112.Name = "checkBox1112";
            this.checkBox1112.Size = new System.Drawing.Size(67, 20);
            this.checkBox1112.TabIndex = 22;
            this.checkBox1112.Text = "11 - 12";
            this.checkBox1112.UseVisualStyleBackColor = true;
            // 
            // checkBox78
            // 
            this.checkBox78.AutoSize = true;
            this.checkBox78.Location = new System.Drawing.Point(139, 213);
            this.checkBox78.Name = "checkBox78";
            this.checkBox78.Size = new System.Drawing.Size(53, 20);
            this.checkBox78.TabIndex = 21;
            this.checkBox78.Text = "7 - 8";
            this.checkBox78.UseVisualStyleBackColor = true;
            // 
            // checkBox34
            // 
            this.checkBox34.AutoSize = true;
            this.checkBox34.Location = new System.Drawing.Point(139, 190);
            this.checkBox34.Name = "checkBox34";
            this.checkBox34.Size = new System.Drawing.Size(53, 20);
            this.checkBox34.TabIndex = 20;
            this.checkBox34.Text = "3 - 4";
            this.checkBox34.UseVisualStyleBackColor = true;
            // 
            // admAccessClick
            // 
            this.admAccessClick.AutoSize = true;
            this.admAccessClick.BackColor = System.Drawing.Color.Black;
            this.admAccessClick.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admAccessClick.ForeColor = System.Drawing.Color.Silver;
            this.admAccessClick.Location = new System.Drawing.Point(1696, 20);
            this.admAccessClick.Name = "admAccessClick";
            this.admAccessClick.Size = new System.Drawing.Size(178, 25);
            this.admAccessClick.TabIndex = 8;
            this.admAccessClick.Text = "ADMIN ACCESS";
            // 
            // groupBoxResults
            // 
            this.groupBoxResults.BackColor = System.Drawing.Color.White;
            this.groupBoxResults.Controls.Add(this.flowLayoutPanel1);
            this.groupBoxResults.Location = new System.Drawing.Point(304, 69);
            this.groupBoxResults.Name = "groupBoxResults";
            this.groupBoxResults.Size = new System.Drawing.Size(1600, 955);
            this.groupBoxResults.TabIndex = 9;
            this.groupBoxResults.TabStop = false;
            this.groupBoxResults.Text = "Résultats";
            // 
            // checkBoxBiggerThan16
            // 
            this.checkBoxBiggerThan16.AutoSize = true;
            this.checkBoxBiggerThan16.Location = new System.Drawing.Point(6, 284);
            this.checkBoxBiggerThan16.Name = "checkBoxBiggerThan16";
            this.checkBoxBiggerThan16.Size = new System.Drawing.Size(53, 20);
            this.checkBoxBiggerThan16.TabIndex = 19;
            this.checkBoxBiggerThan16.Text = "16 >";
            this.checkBoxBiggerThan16.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Silver;
            this.label2.Location = new System.Drawing.Point(16, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(232, 22);
            this.label2.TabIndex = 10;
            this.label2.Text = "VOIR ET RECHERCHER";
            // 
            // groupBoxFilterElements
            // 
            this.groupBoxFilterElements.BackColor = System.Drawing.Color.White;
            this.groupBoxFilterElements.Controls.Add(this.textBoxInStock);
            this.groupBoxFilterElements.Controls.Add(this.comboBoxBoxNumber);
            this.groupBoxFilterElements.Controls.Add(this.textBoxQuantity);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxJauneYellow);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxBrunBrown);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxAutreOther);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxOrGold);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxArgentSilver);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxMauve);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxOrange);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxBlancWhite);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxRose);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxBleueBlue);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxRougeRed);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxNoirBlack);
            this.groupBoxFilterElements.Controls.Add(this.checkBox1516);
            this.groupBoxFilterElements.Controls.Add(this.checkBox1314);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxL);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxM);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxS);
            this.groupBoxFilterElements.Controls.Add(this.checkBox1112);
            this.groupBoxFilterElements.Controls.Add(this.checkBox78);
            this.groupBoxFilterElements.Controls.Add(this.checkBox34);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxBiggerThan16);
            this.groupBoxFilterElements.Controls.Add(this.checkBox910);
            this.groupBoxFilterElements.Controls.Add(this.checkBox56);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxLessThan3);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxVaria);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxDecor);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxAccessoires);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxHautes);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxTShirts);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxJupesSkirts);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxHeadGear);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxBas);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxShorts);
            this.groupBoxFilterElements.Controls.Add(this.checkBoxMailotsLeotards);
            this.groupBoxFilterElements.Controls.Add(this.label3);
            this.groupBoxFilterElements.Controls.Add(this.labelQuantity);
            this.groupBoxFilterElements.Controls.Add(this.labelBoxNo);
            this.groupBoxFilterElements.Controls.Add(this.labelColor);
            this.groupBoxFilterElements.Controls.Add(this.labelSize);
            this.groupBoxFilterElements.Controls.Add(this.labelCategory);
            this.groupBoxFilterElements.Location = new System.Drawing.Point(-2, 69);
            this.groupBoxFilterElements.Name = "groupBoxFilterElements";
            this.groupBoxFilterElements.Size = new System.Drawing.Size(300, 955);
            this.groupBoxFilterElements.TabIndex = 6;
            this.groupBoxFilterElements.TabStop = false;
            this.groupBoxFilterElements.Text = "Filteration";
            // 
            // checkBox910
            // 
            this.checkBox910.AutoSize = true;
            this.checkBox910.Location = new System.Drawing.Point(6, 238);
            this.checkBox910.Name = "checkBox910";
            this.checkBox910.Size = new System.Drawing.Size(63, 20);
            this.checkBox910.TabIndex = 18;
            this.checkBox910.Text = "9 - 10 ";
            this.checkBox910.UseVisualStyleBackColor = true;
            // 
            // checkBox56
            // 
            this.checkBox56.AutoSize = true;
            this.checkBox56.Location = new System.Drawing.Point(6, 213);
            this.checkBox56.Name = "checkBox56";
            this.checkBox56.Size = new System.Drawing.Size(56, 20);
            this.checkBox56.TabIndex = 17;
            this.checkBox56.Text = "5 - 6 ";
            this.checkBox56.UseVisualStyleBackColor = true;
            // 
            // checkBoxLessThan3
            // 
            this.checkBoxLessThan3.AutoSize = true;
            this.checkBoxLessThan3.Location = new System.Drawing.Point(6, 190);
            this.checkBoxLessThan3.Name = "checkBoxLessThan3";
            this.checkBoxLessThan3.Size = new System.Drawing.Size(46, 20);
            this.checkBoxLessThan3.TabIndex = 16;
            this.checkBoxLessThan3.Text = "< 3";
            this.checkBoxLessThan3.UseVisualStyleBackColor = true;
            // 
            // checkBoxVaria
            // 
            this.checkBoxVaria.AutoSize = true;
            this.checkBoxVaria.Location = new System.Drawing.Point(139, 136);
            this.checkBoxVaria.Name = "checkBoxVaria";
            this.checkBoxVaria.Size = new System.Drawing.Size(61, 20);
            this.checkBoxVaria.TabIndex = 15;
            this.checkBoxVaria.Text = "Varia";
            this.checkBoxVaria.UseVisualStyleBackColor = true;
            // 
            // checkBoxDecor
            // 
            this.checkBoxDecor.AutoSize = true;
            this.checkBoxDecor.Location = new System.Drawing.Point(6, 136);
            this.checkBoxDecor.Name = "checkBoxDecor";
            this.checkBoxDecor.Size = new System.Drawing.Size(66, 20);
            this.checkBoxDecor.TabIndex = 14;
            this.checkBoxDecor.Text = "Décor";
            this.checkBoxDecor.UseVisualStyleBackColor = true;
            // 
            // checkBoxAccessoires
            // 
            this.checkBoxAccessoires.AutoSize = true;
            this.checkBoxAccessoires.Location = new System.Drawing.Point(139, 113);
            this.checkBoxAccessoires.Name = "checkBoxAccessoires";
            this.checkBoxAccessoires.Size = new System.Drawing.Size(104, 20);
            this.checkBoxAccessoires.TabIndex = 13;
            this.checkBoxAccessoires.Text = "Accessoires";
            this.checkBoxAccessoires.UseVisualStyleBackColor = true;
            // 
            // checkBoxHautes
            // 
            this.checkBoxHautes.AutoSize = true;
            this.checkBoxHautes.Location = new System.Drawing.Point(139, 90);
            this.checkBoxHautes.Name = "checkBoxHautes";
            this.checkBoxHautes.Size = new System.Drawing.Size(72, 20);
            this.checkBoxHautes.TabIndex = 12;
            this.checkBoxHautes.Text = "Hautes";
            this.checkBoxHautes.UseVisualStyleBackColor = true;
            // 
            // checkBoxTShirts
            // 
            this.checkBoxTShirts.AutoSize = true;
            this.checkBoxTShirts.Location = new System.Drawing.Point(139, 65);
            this.checkBoxTShirts.Name = "checkBoxTShirts";
            this.checkBoxTShirts.Size = new System.Drawing.Size(75, 20);
            this.checkBoxTShirts.TabIndex = 11;
            this.checkBoxTShirts.Text = "T-Shirts";
            this.checkBoxTShirts.UseVisualStyleBackColor = true;
            // 
            // checkBoxJupesSkirts
            // 
            this.checkBoxJupesSkirts.AutoSize = true;
            this.checkBoxJupesSkirts.Location = new System.Drawing.Point(139, 42);
            this.checkBoxJupesSkirts.Name = "checkBoxJupesSkirts";
            this.checkBoxJupesSkirts.Size = new System.Drawing.Size(66, 20);
            this.checkBoxJupesSkirts.TabIndex = 10;
            this.checkBoxJupesSkirts.Text = "Jupes";
            this.checkBoxJupesSkirts.UseVisualStyleBackColor = true;
            // 
            // checkBoxHeadGear
            // 
            this.checkBoxHeadGear.AutoSize = true;
            this.checkBoxHeadGear.Location = new System.Drawing.Point(6, 113);
            this.checkBoxHeadGear.Name = "checkBoxHeadGear";
            this.checkBoxHeadGear.Size = new System.Drawing.Size(115, 20);
            this.checkBoxHeadGear.TabIndex = 9;
            this.checkBoxHeadGear.Text = "Pièces de tête";
            this.checkBoxHeadGear.UseVisualStyleBackColor = true;
            // 
            // checkBoxBas
            // 
            this.checkBoxBas.AutoSize = true;
            this.checkBoxBas.Location = new System.Drawing.Point(6, 90);
            this.checkBoxBas.Name = "checkBoxBas";
            this.checkBoxBas.Size = new System.Drawing.Size(53, 20);
            this.checkBoxBas.TabIndex = 8;
            this.checkBoxBas.Text = "Bas";
            this.checkBoxBas.UseVisualStyleBackColor = true;
            // 
            // checkBoxShorts
            // 
            this.checkBoxShorts.AutoSize = true;
            this.checkBoxShorts.Location = new System.Drawing.Point(6, 65);
            this.checkBoxShorts.Name = "checkBoxShorts";
            this.checkBoxShorts.Size = new System.Drawing.Size(67, 20);
            this.checkBoxShorts.TabIndex = 7;
            this.checkBoxShorts.Text = "Shorts";
            this.checkBoxShorts.UseVisualStyleBackColor = true;
            // 
            // checkBoxMailotsLeotards
            // 
            this.checkBoxMailotsLeotards.AutoSize = true;
            this.checkBoxMailotsLeotards.Location = new System.Drawing.Point(6, 42);
            this.checkBoxMailotsLeotards.Name = "checkBoxMailotsLeotards";
            this.checkBoxMailotsLeotards.Size = new System.Drawing.Size(72, 20);
            this.checkBoxMailotsLeotards.TabIndex = 6;
            this.checkBoxMailotsLeotards.Text = "Mailots";
            this.checkBoxMailotsLeotards.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 578);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "EN STOCK";
            // 
            // labelQuantity
            // 
            this.labelQuantity.AutoSize = true;
            this.labelQuantity.Location = new System.Drawing.Point(31, 512);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new System.Drawing.Size(76, 16);
            this.labelQuantity.TabIndex = 4;
            this.labelQuantity.Text = "QUANTITÉ";
            // 
            // labelBoxNo
            // 
            this.labelBoxNo.AutoSize = true;
            this.labelBoxNo.Location = new System.Drawing.Point(35, 641);
            this.labelBoxNo.Name = "labelBoxNo";
            this.labelBoxNo.Size = new System.Drawing.Size(68, 16);
            this.labelBoxNo.TabIndex = 3;
            this.labelBoxNo.Text = "BOÎTE No";
            // 
            // labelColor
            // 
            this.labelColor.AutoSize = true;
            this.labelColor.Location = new System.Drawing.Point(31, 343);
            this.labelColor.Name = "labelColor";
            this.labelColor.Size = new System.Drawing.Size(72, 16);
            this.labelColor.TabIndex = 2;
            this.labelColor.Text = "COULEUR";
            // 
            // labelSize
            // 
            this.labelSize.AutoSize = true;
            this.labelSize.Location = new System.Drawing.Point(31, 170);
            this.labelSize.Name = "labelSize";
            this.labelSize.Size = new System.Drawing.Size(51, 16);
            this.labelSize.TabIndex = 1;
            this.labelSize.Text = "TAILLE";
            // 
            // labelCategory
            // 
            this.labelCategory.AutoSize = true;
            this.labelCategory.Location = new System.Drawing.Point(31, 22);
            this.labelCategory.Name = "labelCategory";
            this.labelCategory.Size = new System.Drawing.Size(85, 16);
            this.labelCategory.TabIndex = 0;
            this.labelCategory.Text = "CATÉGORIE";
            // 
            // labelSearch
            // 
            this.labelSearch.AutoSize = true;
            this.labelSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearch.ForeColor = System.Drawing.Color.Silver;
            this.labelSearch.Location = new System.Drawing.Point(306, 33);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(147, 22);
            this.labelSearch.TabIndex = 7;
            this.labelSearch.Text = "RECHERCHER";
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(459, 33);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(260, 22);
            this.textBoxSearch.TabIndex = 11;
            // 
            // FormViewSearchTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1902, 1032);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.admAccessClick);
            this.Controls.Add(this.labelSearch);
            this.Controls.Add(this.groupBoxResults);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBoxFilterElements);
            this.Name = "FormViewSearchTest";
            this.Text = "Form1";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBoxResults.ResumeLayout(false);
            this.groupBoxFilterElements.ResumeLayout(false);
            this.groupBoxFilterElements.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBoxInStock;
        private System.Windows.Forms.ComboBox comboBoxBoxNumber;
        private System.Windows.Forms.TextBox textBoxQuantity;
        private System.Windows.Forms.CheckBox checkBoxJauneYellow;
        private System.Windows.Forms.CheckBox checkBoxBrunBrown;
        private System.Windows.Forms.CheckBox checkBoxAutreOther;
        private System.Windows.Forms.CheckBox checkBoxOrGold;
        private System.Windows.Forms.CheckBox checkBoxArgentSilver;
        private System.Windows.Forms.CheckBox checkBoxMauve;
        private System.Windows.Forms.CheckBox checkBoxOrange;
        private System.Windows.Forms.CheckBox checkBoxBlancWhite;
        private System.Windows.Forms.CheckBox checkBoxRose;
        private System.Windows.Forms.CheckBox checkBoxBleueBlue;
        private System.Windows.Forms.CheckBox checkBoxRougeRed;
        private System.Windows.Forms.CheckBox checkBoxNoirBlack;
        private System.Windows.Forms.CheckBox checkBox1516;
        private System.Windows.Forms.CheckBox checkBox1314;
        private System.Windows.Forms.CheckBox checkBoxL;
        private System.Windows.Forms.CheckBox checkBoxM;
        private System.Windows.Forms.CheckBox checkBoxS;
        private System.Windows.Forms.CheckBox checkBox1112;
        private System.Windows.Forms.CheckBox checkBox78;
        private System.Windows.Forms.CheckBox checkBox34;
        private System.Windows.Forms.Label admAccessClick;
        private System.Windows.Forms.GroupBox groupBoxResults;
        private System.Windows.Forms.CheckBox checkBoxBiggerThan16;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBoxFilterElements;
        private System.Windows.Forms.CheckBox checkBox910;
        private System.Windows.Forms.CheckBox checkBox56;
        private System.Windows.Forms.CheckBox checkBoxLessThan3;
        private System.Windows.Forms.CheckBox checkBoxVaria;
        private System.Windows.Forms.CheckBox checkBoxDecor;
        private System.Windows.Forms.CheckBox checkBoxAccessoires;
        private System.Windows.Forms.CheckBox checkBoxHautes;
        private System.Windows.Forms.CheckBox checkBoxTShirts;
        private System.Windows.Forms.CheckBox checkBoxJupesSkirts;
        private System.Windows.Forms.CheckBox checkBoxHeadGear;
        private System.Windows.Forms.CheckBox checkBoxBas;
        private System.Windows.Forms.CheckBox checkBoxShorts;
        private System.Windows.Forms.CheckBox checkBoxMailotsLeotards;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelQuantity;
        private System.Windows.Forms.Label labelBoxNo;
        private System.Windows.Forms.Label labelColor;
        private System.Windows.Forms.Label labelSize;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.Label labelSearch;
        private System.Windows.Forms.TextBox textBoxSearch;
    }
}