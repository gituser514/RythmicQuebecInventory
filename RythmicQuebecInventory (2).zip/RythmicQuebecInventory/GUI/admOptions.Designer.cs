﻿namespace RythmicQuebecInventory
{
    partial class admOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.logOut = new System.Windows.Forms.Label();
            this.admOptionLabel = new System.Windows.Forms.Label();
            this.addItems = new System.Windows.Forms.TextBox();
            this.modiDeleItems = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // logOut
            // 
            this.logOut.AutoSize = true;
            this.logOut.BackColor = System.Drawing.Color.Black;
            this.logOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOut.ForeColor = System.Drawing.Color.Silver;
            this.logOut.Location = new System.Drawing.Point(1010, 30);
            this.logOut.Name = "logOut";
            this.logOut.Size = new System.Drawing.Size(109, 25);
            this.logOut.TabIndex = 0;
            this.logOut.Text = "LOG OUT";
            // 
            // admOptionLabel
            // 
            this.admOptionLabel.AutoSize = true;
            this.admOptionLabel.BackColor = System.Drawing.Color.Black;
            this.admOptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admOptionLabel.ForeColor = System.Drawing.Color.Silver;
            this.admOptionLabel.Location = new System.Drawing.Point(169, 90);
            this.admOptionLabel.Name = "admOptionLabel";
            this.admOptionLabel.Size = new System.Drawing.Size(165, 22);
            this.admOptionLabel.TabIndex = 1;
            this.admOptionLabel.Text = "ADMIN OPTIONS";
            // 
            // addItems
            // 
            this.addItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItems.ForeColor = System.Drawing.Color.Gray;
            this.addItems.Location = new System.Drawing.Point(169, 150);
            this.addItems.Name = "addItems";
            this.addItems.Size = new System.Drawing.Size(300, 34);
            this.addItems.TabIndex = 2;
            this.addItems.Text = "ADD NEW ITEMS";
            this.addItems.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // modiDeleItems
            // 
            this.modiDeleItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modiDeleItems.ForeColor = System.Drawing.Color.Gray;
            this.modiDeleItems.Location = new System.Drawing.Point(169, 195);
            this.modiDeleItems.Name = "modiDeleItems";
            this.modiDeleItems.Size = new System.Drawing.Size(300, 34);
            this.modiDeleItems.TabIndex = 8;
            this.modiDeleItems.Text = "MODIFY / DELETE ITEMS";
            this.modiDeleItems.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.Gray;
            this.textBox2.Location = new System.Drawing.Point(169, 285);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(300, 34);
            this.textBox2.TabIndex = 10;
            this.textBox2.Text = "VIEW / ADD BOXES";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.Gray;
            this.textBox3.Location = new System.Drawing.Point(169, 240);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(300, 34);
            this.textBox3.TabIndex = 9;
            this.textBox3.Text = "ADD DELETE COACHES";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.Color.Gray;
            this.textBox4.Location = new System.Drawing.Point(169, 375);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(300, 34);
            this.textBox4.TabIndex = 12;
            this.textBox4.Text = "CREATE QR CODES";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.ForeColor = System.Drawing.Color.Gray;
            this.textBox5.Location = new System.Drawing.Point(169, 330);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(300, 34);
            this.textBox5.TabIndex = 11;
            this.textBox5.Text = "ITEMS CONTROL";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.Gray;
            this.textBox1.Location = new System.Drawing.Point(169, 420);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(300, 34);
            this.textBox1.TabIndex = 13;
            this.textBox1.Text = "BUCKUP DATABASE";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // admOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1262, 673);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.modiDeleItems);
            this.Controls.Add(this.addItems);
            this.Controls.Add(this.admOptionLabel);
            this.Controls.Add(this.logOut);
            this.ForeColor = System.Drawing.Color.Silver;
            this.Name = "admOptions";
            this.Text = "admOptions";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label logOut;
        private System.Windows.Forms.Label admOptionLabel;
        private System.Windows.Forms.TextBox addItems;
        private System.Windows.Forms.TextBox modiDeleItems;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox1;
    }
}